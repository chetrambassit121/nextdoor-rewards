from django.urls import path

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)



from .views import RegisterView, CurrentUserView, UserProfileView


urlpatterns = [
    path(
        "register/",
        RegisterView.as_view(),
        name="register",
    ),

    path(
        "login/",
        TokenObtainPairView.as_view(),
        name="login",
    ),

    path(
        "refresh/",
        TokenRefreshView.as_view(),
        name="token_refresh",
    ),

    path(
        "me/",
        CurrentUserView.as_view(),
        name="current_user",
    ),

    path(
        "profile/",
        UserProfileView.as_view(),
        name="user-profile",
    ),
]

