
from django.contrib.auth import get_user_model
from django.db import transaction
from django.http import HttpResponse
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.throttling import AnonRateThrottle


GUEST_USERNAME = "guest"
GUEST_EMAIL = "guest@neighborhood-rewards.example"


class GuestLoginThrottle(AnonRateThrottle):
    rate = "10/min"


class GuestLoginView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    throttle_classes = [GuestLoginThrottle]

    def post(self, request):
        User = get_user_model()

        try:
            with transaction.atomic():
                guest, created = User.objects.get_or_create(
                    username=GUEST_USERNAME,
                    defaults={
                        "email": GUEST_EMAIL,
                        "is_active": True,
                        "is_staff": False,
                        "is_superuser": False,
                    },
                )

                if created:
                    guest.set_unusable_password()
                    guest.save(update_fields=["password"])

                if (
                    not guest.is_active
                    or guest.is_staff
                    or guest.is_superuser
                    or guest.has_usable_password()
                ):
                    return Response(
                        {"detail": "Guest account is unavailable."},
                        status=503,
                    )

            refresh = RefreshToken.for_user(guest)
            refresh["is_guest"] = True
            refresh.access_token["is_guest"] = True

            return Response({
                "access": str(refresh.access_token),
                "refresh": str(refresh),
                "user": {
                    "id": guest.pk,
                    "username": guest.username,
                    "is_guest": True,
                },
            })

        except User.MultipleObjectsReturned:
            return Response(
                {"detail": "Guest account configuration error."},
                status=503,
            )
